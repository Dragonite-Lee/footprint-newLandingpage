exports.id = 94;
exports.ids = [94];
exports.modules = {

/***/ 407:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "layout_navbar__W_CG2",
	"navbar_left": "layout_navbar_left__f9nxv",
	"navbar_right": "layout_navbar_right__SEF4R",
	"navbar_logo": "layout_navbar_logo__IbzS9",
	"navbar_intro": "layout_navbar_intro__QYYHU",
	"navbar_ongoing": "layout_navbar_ongoing__xcmnC",
	"navbar_intro_active": "layout_navbar_intro_active__OLlv1",
	"navbar_ongoing_active": "layout_navbar_ongoing_active__IfPSa",
	"footer_web": "layout_footer_web__gdhL_",
	"footer_tablet": "layout_footer_tablet__jTU3c",
	"footer_mobile": "layout_footer_mobile__7vDA9",
	"footer_left_img": "layout_footer_left_img__0Dz_D",
	"footer_right": "layout_footer_right__54_g0",
	"footer_right_contact": "layout_footer_right_contact__BOyNy",
	"footer_right_contact_img": "layout_footer_right_contact_img__yEBS8",
	"instagram": "layout_instagram___hBOS",
	"facebook": "layout_facebook__OkwJa",
	"footer_right_bussiness_img": "layout_footer_right_bussiness_img__z4TtU",
	"navbar_mobile": "layout_navbar_mobile__uHD3T",
	"menu_title": "layout_menu_title__09Hl3",
	"header_wrap": "layout_header_wrap__3Thxn",
	"h_menu": "layout_h_menu__FlHUZ",
	"c_menu": "layout_c_menu__8CqpE",
	"menu_black_tab": "layout_menu_black_tab__S5x1h",
	"main": "layout_main__i6bTv",
	"footer_main_content": "layout_footer_main_content__ETKFM",
	"main_text": "layout_main_text__UOxxS",
	"footer_top": "layout_footer_top__MtXp_",
	"footer_front": "layout_footer_front__m9oCO",
	"main_home": "layout_main_home__uPkPa",
	"main_intro": "layout_main_intro__EzyNI",
	"main_ongoing": "layout_main_ongoing__of1yK",
	"sub_back": "layout_sub_back__rTwhp",
	"sub_back_title": "layout_sub_back_title__pvWeB",
	"footer_back": "layout_footer_back__XXZwS",
	"sub_title": "layout_sub_title__tgEHV",
	"footer_mobile_intro": "layout_footer_mobile_intro__FJi_3",
	"footer_mobile_bussiness": "layout_footer_mobile_bussiness__cWfdW",
	"mobile_instagram": "layout_mobile_instagram__LtUHl",
	"mobile_facebook": "layout_mobile_facebook__06p03",
	"menu_white_tab": "layout_menu_white_tab__Hu6BV",
	"menu_home": "layout_menu_home__1WIRk",
	"menu_intro": "layout_menu_intro__jYC5O",
	"menu_ongoing": "layout_menu_ongoing__FrbBO"
};


/***/ }),

/***/ 2226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./components/layout/layout.module.css
var layout_module = __webpack_require__(407);
var layout_module_default = /*#__PURE__*/__webpack_require__.n(layout_module);
;// CONCATENATED MODULE: ./public/layout/facebook.png
/* harmony default export */ const facebook = ({"src":"/_next/static/media/facebook.4d4049bf.png","height":80,"width":204,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAG1BMVEUAAAAbGxsBAQFMaXEAAABNTU0UFBQAAABaWlo/ZKmpAAAACHRSTlMHLVAAIG9vP6h8cmUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAcSURBVHicY2BhY2RmAAEmDlZmJnZGJgYWVogIAANyADrDICD9AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/layout/instagram.png
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.289b60bb.png","height":80,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAFVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAASAQCkAAAAB3RSTlMCBzcdTi5xOI3IUQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAB5JREFUeJxjYGVmYAQBBjYWRiYmJiYWBlZmBhBgBAAC0AAupvOfbAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/layout/footer_left.png
/* harmony default export */ const footer_left = ({"src":"/_next/static/media/footer_left.148ee9a9.png","height":402,"width":662,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAADFBMVEUAAAAAAAAAAAAAAAA16TeWAAAABHRSTlMYAQsk+AtOxwAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAACFJREFUeJxFxrENAAAIw7Am/f9nBAuenJYTQTctJhshTwYE+AAtfdJfywAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/layout/footer_right_bussiness.png
/* harmony default export */ const footer_right_bussiness = ({"src":"/_next/static/media/footer_right_bussiness.ad6b001c.png","height":456,"width":222,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAMAAADp7a43AAAAD1BMVEUAAAAAAABMaXEAAAAAAADyE3eRAAAABXRSTlMjDAA9F+fnIaQAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAfSURBVHicY2BmZmJiYGRkYmJgYGAEEWAAYTHCWIxMAAMEAB6Hhjp7AAAAAElFTkSuQmCC","blurWidth":4,"blurHeight":8});
;// CONCATENATED MODULE: ./public/layout/footer_right_contact.png
/* harmony default export */ const footer_right_contact = ({"src":"/_next/static/media/footer_right_contact.a1c2908c.png","height":32,"width":214,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAACVBMVEUAAAAAAAAAAACDY+nAAAAAA3RSTlNmQ1AGEz5+AAAACXBIWXMAABYlAAAWJQFJUiTwAAAADklEQVR4nGNgAAEmRgYAABEABBS4bdYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./public/layout/footer_left_img_tablet.png
/* harmony default export */ const footer_left_img_tablet = ({"src":"/_next/static/media/footer_left_img_tablet.e9592d8c.png","height":187,"width":392,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAD1BMVEUAAAAAAAAAAAAAAAAAAABPDueNAAAABXRSTlMnAQ8aNeT06wUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAgSURBVHicHcbBEQAwCIAwBPefuVfzCtsccvJnMVAoAB8D8QAx0EBaNQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/layout/footer_right_bussiness_tablet.png
/* harmony default export */ const footer_right_bussiness_tablet = ({"src":"/_next/static/media/footer_right_bussiness_tablet.c4a485c0.png","height":248,"width":148,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAMAAAAGL8UJAAAAD1BMVEUAAAAAAAAAAAAAAAAAAABPDueNAAAABXRSTlMtIgIUP2pNpLcAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAlSURBVHicFcjBDQAwDINAsLP/zK0/JwRHEmwTgBZQ5764v+a+DwWXADd97kJvAAAAAElFTkSuQmCC","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/layout/footer_right_contact_tablet.png
/* harmony default export */ const footer_right_contact_tablet = ({"src":"/_next/static/media/footer_right_contact_tablet.a5087306.png","height":18,"width":123,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAACVBMVEUAAAAAAAAAAACDY+nAAAAAA3RSTlNqTV3vO5YpAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAEUlEQVR4nGNgYGJiYGBkZAAAACgAB/2yOYcAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":1});
;// CONCATENATED MODULE: ./public/layout/instagram_tablet.png
/* harmony default export */ const instagram_tablet = ({"src":"/_next/static/media/instagram_tablet.165f238a.png","height":34,"width":134,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAADFBMVEUAAAAAAAAAAAAAAAA16TeWAAAABHRSTlMyJyEJIfCrkgAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAABhJREFUeJwFwQEBAAAAgiC1/58DdFUAQ+MA4QAVUwil9AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/layout/facebook_tablet.png
/* harmony default export */ const facebook_tablet = ({"src":"/_next/static/media/facebook_tablet.185a5d98.png","height":36,"width":116,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAElBMVEUAAAAAAAAKCgotLS1MaXFHR0ddWP3HAAAABnRSTlM1J0NwAKvVpId4AAAACXBIWXMAABYlAAAWJQFJUiTwAAAAGklEQVR4nGNgYmZhYGBkZGBgZmVhYGJkYAAAARUAGxq3TvMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/layout/footer_back.png
/* harmony default export */ const footer_back = ({"src":"/_next/static/media/footer_back.dff7d0f1.png","height":24,"width":15,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAMAAAAGL8UJAAAAFVBMVEVMaXEAAAAAAAAAAAAAAAAAAAAAAACpf3wfAAAAB3RSTlMA1I4MEbi5G47j9QAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAABtJREFUeJxjYGBgYGFlYGBgZmRCJqAkGsXCBgAFKwA4IXHXhwAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/layout/footer_front.png
/* harmony default export */ const footer_front = ({"src":"/_next/static/media/footer_front.42f7717b.png","height":24,"width":14,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAMAAAAGL8UJAAAAGFBMVEWQkJCHiIiJioqLi4uBhISQkZGGhoaCiYnKlw/cAAAACHRSTlMBf+chI8A1JVyQXxIAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAjSURBVHicY2BkYmZgYGBgZGKHUGAeKyuMDRZnZGIB8dmAUgAF5QA/r0DtTAAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});
;// CONCATENATED MODULE: ./public/layout/footer_mobile_intro.png
/* harmony default export */ const footer_mobile_intro = ({"src":"/_next/static/media/footer_mobile_intro.d84ee761.png","height":192,"width":342,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAACVBMVEUAAAAAAAAAAACDY+nAAAAAA3RSTlMdEgMPddWUAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAHUlEQVR4nCXGsQ0AAAiAsOL/RxtjF0BzoDSfbl4LAjAAGSFFqv0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/layout/footer_mobile_bussiness.png
/* harmony default export */ const footer_mobile_bussiness = ({"src":"/_next/static/media/footer_mobile_bussiness.ee349eca.png","height":140,"width":330,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAADFBMVEUAAAAAAAAAAAAAAAA16TeWAAAABHRSTlMdARYPnAUrqQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAB1JREFUeJwVyLENAAAMgzAg//9c1aOJHBPSVYD+HgHlACE9Qe0bAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/layout/mobile_instagram.png
/* harmony default export */ const mobile_instagram = ({"src":"/_next/static/media/mobile_instagram.156b9772.png","height":36,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAMAAABSSm3fAAAAD1BMVEUAAAAAAAAAAAAAAAAAAABPDueNAAAABXRSTlMjTSoUOvAMHlQAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAXSURBVHicY2BkYGZiYGBgYQAxmBgYGAEAwQAUzxj27wAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./public/layout/mobile_facebook.png
/* harmony default export */ const mobile_facebook = ({"src":"/_next/static/media/mobile_facebook.ce869721.png","height":36,"width":110,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAHlBMVEUKCgoAAAADAwMAAAAjIyNNTU0AAAAAAAAAAABmZmaTPuxlAAAACnRSTlMFD1EYSHBobzLkalp0IwAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAACBJREFUeJwFwYEBACAIw7CWoeD/D5vQoCCPmtq+HIjRDwMFADy5KoAiAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":3});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/layout/footer.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



















function Footer() {
    const [footerHome, setFooterHome] = (0,external_react_.useState)(false);
    const [footerIntro, setFooterIntro] = (0,external_react_.useState)(false);
    const [footerOngoing, setFooterOngoing] = (0,external_react_.useState)(false);
    const footer_main = (0,external_react_.useRef)(null);
    const footer_home = (0,external_react_.useRef)(null);
    const footer_intro = (0,external_react_.useRef)(null);
    const footer_ongoing = (0,external_react_.useRef)(null);
    const footerMobileStateHandler = (e)=>{
        if (e.target == footer_home.current && footer_main.current) {
            setFooterHome(true);
            footer_main.current.style.display = "none";
        } else if (e.target == footer_intro.current && footer_main.current) {
            setFooterIntro(true);
            footer_main.current.style.display = "none";
        } else if (e.target == footer_ongoing.current && footer_main.current) {
            setFooterOngoing(true);
            footer_main.current.style.display = "none";
        }
    };
    const footerMobileStateBackHandler = ()=>{
        if (footer_main.current) {
            setFooterHome(false);
            setFooterIntro(false);
            setFooterOngoing(false);
            footer_main.current.style.display = "flex";
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("footer", {
                className: (layout_module_default()).footer_web,
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            src: footer_left,
                            className: (layout_module_default()).footer_left_img,
                            alt: "footer_left이미지"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (layout_module_default()).footer_right,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: (layout_module_default()).footer_right_contact,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_right_contact,
                                        className: (layout_module_default()).footer_right_contact_img,
                                        alt: "footer_right_contact이미지"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: instagram,
                                        className: (layout_module_default()).instagram,
                                        alt: "instagram이미지",
                                        onClick: ()=>{
                                            window.open("https://www.instagram.com/footprint_story/");
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: facebook,
                                        className: (layout_module_default()).facebook,
                                        alt: "facebook이미지",
                                        onClick: ()=>{
                                            window.open("https://www.facebook.com/footprintcareers?mibextid=ZbWKwL");
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: (layout_module_default()).footer_right_bussiness,
                                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: footer_right_bussiness,
                                    className: (layout_module_default()).footer_right_bussiness_img,
                                    alt: "footer_right_bussiness이미지"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("footer", {
                className: (layout_module_default()).footer_tablet,
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            src: footer_left_img_tablet,
                            className: (layout_module_default()).footer_left_img,
                            alt: "footer_left이미지"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (layout_module_default()).footer_right,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: (layout_module_default()).footer_right_contact,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_right_contact_tablet,
                                        className: (layout_module_default()).footer_right_contact_img,
                                        alt: "footer_right_contact이미지"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: instagram_tablet,
                                        className: (layout_module_default()).instagram,
                                        alt: "instagram이미지",
                                        onClick: ()=>{
                                            window.open("https://www.instagram.com/footprint_story/");
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: facebook_tablet,
                                        className: (layout_module_default()).facebook,
                                        alt: "facebook이미지",
                                        onClick: ()=>{
                                            window.open("https://www.facebook.com/footprintcareers?mibextid=ZbWKwL");
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: (layout_module_default()).footer_right_bussiness_mobile,
                                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: footer_right_bussiness_tablet,
                                    className: (layout_module_default()).footer_right_bussiness_img,
                                    alt: "footer_right_bussiness이미지"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("footer", {
                className: (layout_module_default()).footer_mobile,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (layout_module_default()).footer_main_content,
                        ref: footer_main,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                onClick: (e)=>footerMobileStateHandler(e),
                                className: (layout_module_default()).footer_top,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).main_text,
                                        ref: footer_home,
                                        children: "풋프린트"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_front,
                                        className: (layout_module_default()).footer_front,
                                        alt: "footer_back"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                onClick: (e)=>footerMobileStateHandler(e),
                                className: (layout_module_default()).footer_top,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).main_text,
                                        ref: footer_intro,
                                        children: "Contact us"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_front,
                                        className: (layout_module_default()).footer_front,
                                        alt: "footer_back"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                onClick: (e)=>footerMobileStateHandler(e),
                                className: (layout_module_default()).footer_top,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).main_text,
                                        ref: footer_ongoing,
                                        children: "협력사"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_front,
                                        className: (layout_module_default()).footer_front,
                                        alt: "footer_back"
                                    })
                                ]
                            })
                        ]
                    }),
                    footerHome && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (layout_module_default()).sub_back,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: (layout_module_default()).sub_back_title,
                                onClick: footerMobileStateBackHandler,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_back,
                                        className: (layout_module_default()).footer_back,
                                        alt: "footer_back"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).sub_title,
                                        children: "풋프린트"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: footer_mobile_intro,
                                className: (layout_module_default()).footer_mobile_intro,
                                alt: "footer_mobile_intro"
                            })
                        ]
                    }),
                    footerIntro && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (layout_module_default()).sub_back,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: (layout_module_default()).sub_back_title,
                                onClick: footerMobileStateBackHandler,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_back,
                                        className: (layout_module_default()).footer_back,
                                        alt: "footer_back"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).sub_title,
                                        children: "Contact us"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: mobile_instagram,
                                className: (layout_module_default()).mobile_instagram,
                                alt: "mobile_instagram",
                                onClick: ()=>{
                                    window.open("https://www.instagram.com/footprint_story/");
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: mobile_facebook,
                                className: (layout_module_default()).mobile_facebook,
                                alt: "mobile_facebook",
                                onClick: ()=>{
                                    window.open("https://www.facebook.com/footprintcareers?mibextid=ZbWKwL");
                                }
                            })
                        ]
                    }),
                    footerOngoing && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (layout_module_default()).sub_back,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: (layout_module_default()).sub_back_title,
                                onClick: footerMobileStateBackHandler,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: footer_back,
                                        className: (layout_module_default()).footer_back,
                                        alt: "footer_back"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).sub_title,
                                        children: "협력사"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: footer_mobile_bussiness,
                                className: (layout_module_default()).footer_mobile_bussiness,
                                alt: "footer_mobile_bussiness"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const footer = (Footer);


/***/ }),

/***/ 6209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./components/layout/layout.module.css
var layout_module = __webpack_require__(407);
var layout_module_default = /*#__PURE__*/__webpack_require__.n(layout_module);
;// CONCATENATED MODULE: ./public/layout/navbar_logo.png
/* harmony default export */ const navbar_logo = ({"src":"/_next/static/media/navbar_logo.8dd98808.png","height":48,"width":148,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAIVBMVEUmHhsjFxNMaXEeFRIkFxQnGhMhFxI9Jh5oVDchFhIiFxNjVxK7AAAAC3RSTlMNYAAbOyd5nlh6THs/8TUAAAAJcEhZcwAAITgAACE4AUWWMWAAAAAgSURBVHicBcGHAQAgDMMwZ0DL/w8jsQQgjN6VVOJTgz8DfAA/cH1PJAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":3});
;// CONCATENATED MODULE: ./public/layout/h_menu.png
/* harmony default export */ const h_menu = ({"src":"/_next/static/media/h_menu.f73f50ad.png","height":26,"width":26,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAGFBMVEVMaXEAAAAAAAAAAAAAAAAAAAAAAAAAAACrC2ehAAAACHRSTlMAWJMqnF4aQZcccEIAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAiSURBVHicY2CAAWYWJiYmJhZ2uAADGysjIyMjKzOCgVsxAA4JAGN73Hq/AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/layout/c_menu.png
/* harmony default export */ const c_menu = ({"src":"/_next/static/media/c_menu.f80d12c0.png","height":70,"width":70,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAFVBMVEWCgoJMaXGDg4ODg4P///9/f3+Dg4PPEU1yAAAAB3RSTlMgADa/AQKzkDUqrQAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAADBJREFUeJwdi7kNADAMhOD87D9y5BRIFID2TCsSDScbCmmpwqHNbhykoHINHuj8/QER6QB92OACcQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9332);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "timers"
var external_timers_ = __webpack_require__(9512);
;// CONCATENATED MODULE: ./components/layout/header.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









function Header() {
    let url = (0,navigation.usePathname)();
    const menu_black = (0,external_react_.useRef)(null);
    const menu_white = (0,external_react_.useRef)(null);
    const menu_wrap = (0,external_react_.useRef)(null);
    const [menuCurrent, setMenuCurrent] = (0,external_react_.useState)(false);
    const openModal = ()=>{
        if (menu_black.current && menu_white.current && menu_wrap.current) {
            menu_black.current.style.background = "rgba(0,0,0,0.3)";
            menu_black.current.style.transition = "background 1s ease";
            menu_black.current.style.zIndex = "7";
            menu_white.current.style.transform = "translateX(0%)";
            menu_white.current.style.transition = "transform 1s ease";
        }
        (0,external_timers_.setTimeout)(()=>{
            setMenuCurrent(true);
        }, 300);
    };
    const closeModal = ()=>{
        if (menu_black.current && menu_white.current && menu_wrap.current) {
            menu_black.current.style.background = "rgba(0,0,0,0)";
            menu_black.current.style.transition = "background 1s ease";
            menu_white.current.style.zIndex = "7";
            menu_white.current.style.transform = "translateX(200%)";
            menu_white.current.style.transition = "transform 1s ease";
        }
        (0,external_timers_.setTimeout)(()=>{
            if (menu_black.current && menu_wrap.current) {
                menu_black.current.style.zIndex = "4";
                menu_wrap.current.style.zIndex = "8";
            }
            setMenuCurrent(false);
        }, 300);
    };
    const closeBlackModal = (e)=>{
        if (e.target === menu_black.current) {
            if (menu_black.current && menu_white.current && menu_wrap.current) {
                menu_black.current.style.background = "rgba(0,0,0,0)";
                menu_black.current.style.transition = "background 1s ease";
                menu_white.current.style.zIndex = "8";
                menu_white.current.style.transform = "translateX(200%)";
                menu_white.current.style.transition = "transform 1s ease";
            }
            (0,external_timers_.setTimeout)(()=>{
                if (menu_black.current && menu_wrap.current) {
                    menu_black.current.style.zIndex = "4";
                    menu_wrap.current.style.zIndex = "8";
                }
                setMenuCurrent(false);
            }, 300);
        }
    };
    (0,external_react_.useEffect)(()=>{
        const setScreenSize = ()=>{
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty("--vh", `${vh}px`);
        };
        setScreenSize();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("header", {
                className: (layout_module_default()).navbar,
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                        href: "/",
                        className: (layout_module_default()).navbar_left,
                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            src: navbar_logo,
                            className: (layout_module_default()).navbar_logo,
                            alt: "navbar_logo이미지",
                            priority: true
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (layout_module_default()).navbar_right,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "/Intro",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: url === "/Intro" ? (layout_module_default()).navbar_intro_active : (layout_module_default()).navbar_intro,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            className: "font_bold",
                                            children: "footprint"
                                        }),
                                        " 소개"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "/Ongoing",
                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: url === "/Ongoing" ? (layout_module_default()).navbar_ongoing_active : (layout_module_default()).navbar_ongoing,
                                    children: "연재 중인 스토리"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("header", {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: (layout_module_default()).menu_black_tab,
                        ref: menu_black,
                        onClick: (e)=>closeBlackModal(e),
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: (layout_module_default()).menu_white_tab,
                            ref: menu_white,
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).menu_title,
                                        onClick: closeModal,
                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            className: "font_bold",
                                            children: "footprint"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/Intro",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: (layout_module_default()).menu_title,
                                        onClick: closeModal,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                className: "font_bold",
                                                children: "브랜드"
                                            }),
                                            " 소개"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/Ongoing",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: (layout_module_default()).menu_title,
                                        onClick: closeModal,
                                        children: "연재 중인 스토리"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: (layout_module_default()).header_wrap,
                        ref: menu_wrap,
                        children: menuCurrent ? /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            src: c_menu,
                            className: (layout_module_default()).c_menu,
                            alt: "c_menu",
                            onClick: closeModal
                        }) : /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            src: h_menu,
                            className: (layout_module_default()).h_menu,
                            alt: "h_menu",
                            onClick: openModal
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const header = (Header);


/***/ })

};
;